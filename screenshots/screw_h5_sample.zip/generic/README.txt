Generic offline H5 playable
Open index.html in a browser (preferably via a local static server).
CTA opens: https://example.com/app
Responsive: stage uses contain/letterbox to fit phones, tablets, foldables.
No ad-network SDK required.
